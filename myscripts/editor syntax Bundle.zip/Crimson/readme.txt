Place these files in the following folders of Crimson Editor:

- link -
extension.lst
extension.pcc
extension.pcg

(This will automatically select the PCGen.key & PCGen.spc whenever files of that extension are used.)

- spec -
PCGen.key
PCGen.spc

(Key and spc hold the keywords and delimiters, as well as other settings).


[SETTINGS I've Found Useful]

Tab Spacing needs to be set to 6 for standard pcgen files
New Courier 9 (Defaults to 10) - I find easier on my eyes.
Enable View of 'Spaces', 'Tabs'